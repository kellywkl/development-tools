import React, { useState } from 'react';

const Hook = () => {
  const [count, setCount] = useState(0);
  return (
    <div>
      <p>你点击的次数：{count}</p>
      <button onClick={()=>setCount(count+1)}>点击</button>
      <button onClick={()=>setCount(0)}>重置</button>
    </div>
  )
}

export default Hook